//
//  Constantes.swift
//  PHARMAINVENTapp
//
//  Created by CATALINA MAC  on 5/21/24.
//

import Foundation
import SwiftUI
let colorNaranja=Color(#colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1))
let colorNegro=Color(#colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1))

let colorBtn=Color(#colorLiteral(red: 0.05882352963, green: 0.180392161, blue: 0.2470588237, alpha: 1))
let colorFondo=Color(#colorLiteral(red: 0.1143133611, green: 0.3411764801, blue: 0.3369457322, alpha: 1))





let colorr=Color(#colorLiteral(red: 0.945167917, green: 1, blue: 0.9941093106, alpha: 1))
