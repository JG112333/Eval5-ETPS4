//
//  PHARMAINVENTappApp.swift
//  PHARMAINVENTapp
//
//  Created by CATALINA MAC  on 5/21/24.
//

import SwiftUI

@main
struct PHARMAINVENTappApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
